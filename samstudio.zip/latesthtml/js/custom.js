// JavaScript Document

$(document).ready(function() {
	
	// fullpage scroll
	
	$('#fullpage').fullpage({
		anchors: ['index', 'firstPage', 'secondPage', '3rdPage', '4rdPage', '5rdPage'],
		sectionsColor: ['#fff', '#fff', '#fff'],
		navigation: false,
		navigationPosition: 'right',
		menu: '#menu',
		scrollOverflow: false,
		responsiveWidth: 1200,
		afterResponsive: function(isResponsive){
				
		}
		

	});
	
	$(window).resize(function(){
		if ($(window).width() <= 1200){	
			
			
			$('#fullpage').fullpage({
				scrollOverflow: false,
			});
			
		}	
	});
	
	$(document).on('click', '.scroll-down', function(e){
		e.preventDefault();
		console.log('test');
		$.fn.fullpage.moveSectionDown();
	})
	
	//$(document).on('click', '.lock', function() {
//	  $.fn.fullpage.setAllowScrolling(false);
//	  $.fn.fullpage.setKeyboardScrolling(false);
//	});
//	
//	$(document).on('click', '.close-modal', function() {
//	  $.fn.fullpage.setAllowScrolling(true);
//	  $.fn.fullpage.setKeyboardScrolling(true);
//	});
	
	
	//$('.lock').click(function(e){
//		e.preventDefault();
//		$.fn.fullpage.setAllowScrolling(false);
//		$.fn.fullpage.setKeyboardScrolling(false);
//	});
//
//	$('.close-modal').click(function(e){
//		e.preventDefault();
//		$.fn.fullpage.setAllowScrolling(true);
//		$.fn.fullpage.setKeyboardScrolling(true);
//	});
	
	// fullpage scroll end
	
	// meanu down
	
		//$(".lock").click(function(){
//			$("html").addClass("hiddenall");
//		});
//		
//		$(".removejs").click(function(){
//			$("html").removeClass("hiddenall");
//		});
		
		$(".container1").click(function(){
			$(".menudown").toggleClass("menudownOn");
		});
		
		$(".container2").click(function(){
			$(".menu-slide.mobile").toggleClass("mobileslide");
			$(".nominee").toggleClass("nav-sidebar-open");
		});	
		
		$(".container1").click(function(){
			$(".nominee").toggleClass("nav-sidebar-open");
			$(".header").toggleClass("headerslide");
			$(".nav-main").toggleClass("clicknav");
			$(".scroll-both").toggleClass("scrolloff");
			$(".down").toggleClass("scrolloff")
			$(".box-menu").toggleClass("box-menu-off");
			$(".box-menuother").toggleClass("box-menu-off");
		});
		
		$(".wrapper").click(function(){
			$(".nominee").removeClass("nav-sidebar-open");
			$(".header").removeClass("headerslide");
			$(".nav-main").removeClass("clicknav");
			$(".scroll-both").removeClass("scrolloff");
			$(".down").removeClass("scrolloff")
			$(".box-menu").removeClass("box-menu-off");
			$(".box-menuother").removeClass("box-menu-off");
			$(".menu-slide.mobile").removeClass("mobileslide");
		});
		
		$(".removeslide").click(function(){
			$(".nominee").removeClass("nav-sidebar-open");
			$(".header").removeClass("headerslide");
			$(".nav-main").removeClass("clicknav");
			$(".box-menu").removeClass("box-menu-off");
			$(".down").removeClass("scrolloff");
			$(".menu-slide.mobile").removeClass("mobileslide");
			$(".box-menuother").removeClass("box-menu-off");
		});
		
		$(".apfm-close-button").click(function(){
			$(".single-item .slick-slide div .item").scrollTop(0);
		});
		
		$("button").click(function(){
			$(".overlay").addClass("fadeinbox");
		});
		$(".close").click(function(){
			$(".overlay").removeClass("fadeinbox");
		});
		
		// meanu down
		
		// Carosuel slide animation
		
		/* Demo Scripts for Bootstrap Carousel and Animate.css article
		* on SitePoint by Maria Antonietta Perna
		*/
		(function($) {
		  //Function to animate slider captions
		  function doAnimations(elems) {
			//Cache the animationend event in a variable
			var animEndEv = "webkitAnimationEnd animationend";
		
			elems.each(function() {
			  var $this = $(this),
				$animationType = $this.data("animation");
			  $this.addClass($animationType).one(animEndEv, function() {
				$this.removeClass($animationType);
			  });
			});
		  }
		
		  //Variables on page load
		  var $myCarousel = $("#carouselExampleFade"),
			$firstAnimatingElems = $myCarousel
			  .find(".carousel-item:first")
			  .find("[data-animation ^= 'animated']");
		
		  //Initialize carousel
		  $myCarousel.carousel();
		
		  //Animate captions in first slide on page load
		  doAnimations($firstAnimatingElems);
		
		  //Other slides to be animated on carousel slide event
		  $myCarousel.on("slide.bs.carousel", function(e) {
			var $animatingElems = $(e.relatedTarget).find(
			  "[data-animation ^= 'animated']"
			);
			doAnimations($animatingElems);
		  });
		})(jQuery);
		
		// Carosuel slide animation
		
		//scroll down
		
		
		// team slide
		
		$('.fade1').slick({
		  dots: false,
		  infinite: true,
		  speed: 500,
		  fade: true,
		  cssEase: 'linear'
		});
		
		// team slide end
		
		// modal popup porfolio
			
		$('#modal-content-1').apFullscreenModal({
			openSelector: '#open-modal-1',
			closeSelector: '.close-modal, #send-1'
		});
		
		$('#modal-content-2').apFullscreenModal({
			backgroundColor: '#fff',
			openSelector: '#open-modal-2',
			closeSelector: '.close-modal, #send-2',
		});
		
		$('#modal-content-3').apFullscreenModal({
			backgroundColor: '#fff',
			openSelector: '#open-modal-3',
			closeSelector: '.close-modal, #send-2',
		});
		
		$('#modal-content-4').apFullscreenModal({
			backgroundColor: '#fff',
			openSelector: '#open-modal-4',
			closeSelector: '.close-modal, #send-2',
		});
		
		$('#modal-content-5').apFullscreenModal({
			backgroundColor: '#fff',
			openSelector: '#open-modal-5',
			closeSelector: '.close-modal, #send-2',
		});
		
		$('#modal-content-6').apFullscreenModal({
			backgroundColor: '#fff',
			openSelector: '#open-modal-6',
			closeSelector: '.close-modal, #send-2',
		});
		
		$('#modal-content-7').apFullscreenModal({
			backgroundColor: '#fff',
			openSelector: '#open-modal-7',
			closeSelector: '.close-modal, #send-2',
		});
		
		$('#modal-content-8').apFullscreenModal({
			backgroundColor: '#fff',
			openSelector: '#open-modal-8',
			closeSelector: '.close-modal, #send-2',
		});
		
		$('#modal-content-9').apFullscreenModal({
			backgroundColor: '#fff',
			openSelector: '#open-modal-9',
			closeSelector: '.close-modal, #send-2',
		});
		
		$('#modal-content-10').apFullscreenModal({
			backgroundColor: '#fff',
			openSelector: '#open-modal-10',
			closeSelector: '.close-modal, #send-2',
		});
		
		// modal popup porfolio end
		
		// Modal Slide
		
		$('.single-item').slick({
		dots: false,
		infinite: true,
		speed: 300,
		slidesToShow: 1,
		adaptiveHeight: false,
		fade: true,
		cssEase: 'linear',
		slidesToShow: 1,
		slidesToScroll: 1,
		responsive: [
			{
			  breakpoint: 1024,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1,
				infinite: true,
				dots: false
			  }
			},
			{
			  breakpoint: 600,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			  }
			},
			{
			  breakpoint: 480,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			  }
			}
			// You can unslick at a given breakpoint now by adding:
			// settings: "unslick"
			// instead of a settings object
		  ]
		});
		
		$('.single-item1').slick({
		dots: false,
		infinite: true,
		speed: 300,
		slidesToShow: 1,
		adaptiveHeight: false,
		fade: true,
		cssEase: 'linear',
		slidesToShow: 1,
		slidesToScroll: 1,
		responsive: [
			{
			  breakpoint: 1024,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1,
				infinite: true,
				dots: false
			  }
			},
			{
			  breakpoint: 600,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			  }
			},
			{
			  breakpoint: 480,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			  }
			}
			// You can unslick at a given breakpoint now by adding:
			// settings: "unslick"
			// instead of a settings object
		  ]
		});
		
		// Modal Slide end
		
		jQuery('.scrollbar-inner').scrollbar();
		
		$("img.lazy").lazyload();

});